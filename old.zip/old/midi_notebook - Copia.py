import threading
import rtmidi_python as rtmidi
import sys
import time
import datetime
import signal
from midiutil.MidiFile import MIDIFile

# CONFIGURATION
LONG_PAUSE = 30 # save automatically if there are not new events for 30 seconds
MIDI_FILE_NAME = "midi_notebook_{0}.mid" # {0} = datetime
# /CONFIGURATION


class MetaSingleton(type):
    instance = None
    def __call__(self, *args, **kw):
        if self.instance == None:
            self.instance = super(MetaSingleton, self).__call__(*args, **kw)
        return self.instance

class MidiNotebookContext(object):
    __metaclass__ = MetaSingleton
    
    def __init__(self):
        time.clock()
        self.last_event = time.clock()
        self.messages_captured=[]

MidiNotebookContext()
MidiNotebookContext()

time.clock()
last_event = time.clock()
messages_captured=[]

def save_buffer(messages):
    MyMIDI = MIDIFile(1)
    track = 0   
    track_time = 0
    bpm  = 120
    MyMIDI.addTrackName(track,track_time,"Track")
    MyMIDI.addTempo(track,track_time,bpm)
    
    total_time=0
    midi_messages_on=[]
    midi_messages_off=[]
    midi_messages_controller=[]
    
    for l in messages:
        message = l.split()
            
        total_time += float(message[3])
        total_time_adjusted = total_time * float(bpm) / float(60) # seconds -> beat conversion
        if message[0]=="144": # note on
            midi_messages_on.append({'note': int(message[1]), 'velocity': int(message[2]), 'time': total_time_adjusted})
        elif message[0]=="128": # note off
            midi_messages_off.append({'note': int(message[1]), 'velocity': int(message[2]), 'time': total_time_adjusted})
        elif message[0]=="176": # pedal
            midi_messages_controller.append({'type': int(message[1]), 'value': int(message[2]), 'time': total_time_adjusted})
        
    for m_on in midi_messages_on:
        for m_off in midi_messages_off:
            if m_off['note']==m_on['note']:
                m_on['duration'] = m_off['time'] - m_on['time']
                m_off['note']=-1
                break
        else:
            m_on['duration'] = float(100) # suspended

    track = 0
    channel = 0
    
    for m in midi_messages_on:
        MyMIDI.addNote(track,channel,int(m['note']),m['time'],m['duration'],m['velocity'])

    for m in midi_messages_controller:
        MyMIDI.addControllerEvent(track, channel, m['time'], m['type'], m['value'])
    
    file_name=MIDI_FILE_NAME.format(datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    print ("Saving {0} MIDI messages to {1}...".format(len(messages_captured), file_name))
    binfile = open(file_name, 'wb')
    MyMIDI.writeFile(binfile)
    binfile.close()
    messages[:]=[]
    print ("Saved.")

def signal_handler(signal, frame):
        global messages_captured
        if len(messages_captured) > 0: save_buffer(messages_captured)
        print('Bye.')
        exit(0)

def callback(message, time_stamp):
    if len(messages_captured) == 0: time_stamp = 0
    message = "{0} {1} {2} {3}".format(message[0], message[1], message[2], time_stamp)
    messages_captured.append(message)
    print(message)
    global last_event
    last_event=time.clock()

input_port = None
for arg in sys.argv[1:]:
    if arg.startswith("-p"):
        input_port = int(arg[2:])

print ("MIDI IN PORTS:")
midi_in = rtmidi.MidiIn()
for n, port_name in enumerate(midi_in.ports):
    selected = ""
    if n==input_port: selected = " [SELECTED] "
    print("({0}) {1}{2}".format(n, port_name, selected))    
print("")

if input_port is None:
    print ("Usage: {0} -pN: select the Nth midi input port.".format(sys.argv[0]))
    print ("Example: {} -p2".format(sys.argv[0]))
    exit(0)

midi_in.callback = callback
midi_in.open_port(input_port)

signal.signal(signal.SIGINT, signal_handler)
print('Press Ctrl+C to save and exit.')
while (True):
    try:
        time.sleep(1)
    except IOError: 
        pass
        
    if (time.clock()-last_event > LONG_PAUSE and len(messages_captured)>0):
        save_buffer(messages_captured)

        
        
        

        
        
        
    


    
