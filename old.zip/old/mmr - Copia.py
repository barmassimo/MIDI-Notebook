import threading
import rtmidi_python as rtmidi
import sys
import time
import datetime
import signal

IN_PORT = 3
OUT_PORT = 3

exit = False

def signal_handler(signal, frame):
        print('Bye.')
        global exit
        exit = True

print ("-- MIDI IN PORTS:")
midi_in = rtmidi.MidiIn()
for port_name in midi_in.ports:
    print(port_name)
    
print("")

print ("-- MIDI OUT PORTS:")
midi_out = rtmidi.MidiOut()
for port_name in midi_out.ports:
    print(port_name)
    
if len(sys.argv) == 1:

    f = open("midi.txt", "a", 0)
    f.write("# "+str(datetime.datetime.now())+"\n")
    
    def callback(message, time_stamp):
        message = "{0} {1} {2} {3}".format(message[0], message[1], message[2], time_stamp)
        global f
        f.write(message+"\n")
        # f.flush()
        print(message)
        
    midi_in = rtmidi.MidiIn()
    midi_in.callback = callback
    midi_in.open_port(IN_PORT)

    print ("")

    signal.signal(signal.SIGINT, signal_handler)
    print('Press Ctrl+C')
    while (not exit):
        try:
            time.sleep(1)
        except IOError: 
            print exit
            pass
        
    f.close()

else:
    midi_messages=[]
    with open(sys.argv[1], "r") as f:
        for l in f.readlines():
            if l and l[0]!="#":
                midi_messages.append(l.split())
            
    midi_out.open_port(OUT_PORT)

    elapsed_time=0
    
    for m in midi_messages:
        time.sleep(float(m[3])-elapsed_time)
        t = time.clock()
        midi_out.send_message([int(m[0]), int(m[1]), int(m[2])])
        elapsed_time = time.clock() - t
        
        
        
    


    
