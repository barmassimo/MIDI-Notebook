import threading
import rtmidi_python as rtmidi
import sys
import time
import datetime
import signal

IN_PORT = 3
OUT_PORT = 3
LONG_PAUSE = 5

time.clock()
last_event = time.clock()

messages_captured=[]

def save_buffer(messages):
    print ("Saving ({0} MIDI messages)...".format(len(messages_captured)))
    # ...
    messages[:]=[]
    print ("Saved.")

def signal_handler(signal, frame):
        global messages_captured
        if len(messages_captured) > 0: save_buffer(messages_captured)
        print('Bye.')
        exit(0)

print ("-- MIDI IN PORTS:")
midi_in = rtmidi.MidiIn()
for port_name in midi_in.ports:
    print(port_name)
    
print("")

print ("-- MIDI OUT PORTS:")
midi_out = rtmidi.MidiOut()
for port_name in midi_out.ports:
    print(port_name)

def callback(message, time_stamp):
    message = "{0} {1} {2} {3}".format(message[0], message[1], message[2], time_stamp)
    messages_captured.append(message)
    print(message)
    global last_event
    last_event=time.clock()
    
midi_in = rtmidi.MidiIn()
midi_in.callback = callback
midi_in.open_port(IN_PORT)

print ("")

signal.signal(signal.SIGINT, signal_handler)
print('Press Ctrl+C to save and exit.')
while (True):
    try:
        time.sleep(1)
    except IOError: 
        pass
        
    global last_event
    if (time.clock()-last_event > LONG_PAUSE and len(messages_captured)>0):
        save_buffer(messages_captured)

        
        
        

        
        
        
    


    
