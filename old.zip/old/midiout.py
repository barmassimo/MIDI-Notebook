import sys
from midiutil.MidiFile import MIDIFile

# Create the MIDIFile Object with 1 track
MyMIDI = MIDIFile(1)

# Tracks are numbered from zero. Times are measured in beats.

track = 0   
time = 0
bpm  = 120

# Add track name and tempo.
MyMIDI.addTrackName(track,time,"Sample Track")
MyMIDI.addTempo(track,time,bpm)

total_time = 0
midi_messages_on=[]
midi_messages_off=[]
midi_messages_controller=[]
with open(sys.argv[1], "r") as f:
    for l in f.readlines():
        if l and l[0]!="#":
            message = l.split()
            total_time += float(message[3]) * float(bpm) / float(60)
            if message[0]=="144": # note on
                midi_messages_on.append({'note': int(message[1]), 'velocity': int(message[2]), 'time': total_time})
            elif message[0]=="128": # note off
                midi_messages_off.append({'note': int(message[1]), 'velocity': int(message[2]), 'time': total_time})
            elif message[0]=="176": # pedal
                midi_messages_controller.append({'type': int(message[1]), 'value': int(message[2]), 'time': total_time})
    
for m_on in midi_messages_on:
    for m_off in midi_messages_off:
        if m_off['note']==m_on['note']:
            m_on['duration'] = m_off['time'] - m_on['time']
            m_off['note']=-1
            break

track = 0
channel = 0
    
for m in midi_messages_on:
    MyMIDI.addNote(track,channel,int(m['note']),m['time'],m['duration'],m['velocity'])

for m in midi_messages_controller:
    MyMIDI.addControllerEvent(track, channel, m['time'], m['type'], m['value'])

# And write it to disk.
binfile = open("output.mid", 'wb')
MyMIDI.writeFile(binfile)
binfile.close()